# Aviation Safety Platform — Backend

A multi-tenant aviation safety incident reporting platform built with Django, DRF, Celery, and PostgreSQL.

## Stack

| Layer | Technology |
|---|---|
| API | Django 5.x + Django REST Framework |
| Auth | Simple JWT |
| Async | Celery + Redis |
| Database | PostgreSQL 16 |
| Cache | Redis |
| Container | Docker + Docker Compose |
| Tests | pytest + pytest-django |

## Local development

### 1. Clone and configure

```bash
git clone https://github.com/OerangWutang/aviation-safety-platform
cd aviation-safety-platform
cp .env.example .env
```

### 2. Boot

```bash
docker-compose up --build
```

### 3. Migrate and create superuser

```bash
docker-compose exec api python manage.py migrate
docker-compose exec api python manage.py createsuperuser
```

### 4. Run tests

```bash
docker-compose exec api pytest
```

## Environment variables

| Variable | Description |
|---|---|
| `DJANGO_SETTINGS_MODULE` | Settings module to use |
| `SECRET_KEY` | Django secret key |
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis URL for cache |
| `CELERY_BROKER_URL` | Redis URL for Celery broker |
| `CELERY_RESULT_BACKEND` | Redis URL for Celery results |

## API endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/v1/health/` | Health check (public) |
| POST | `/api/v1/token/` | Obtain JWT token pair |
| POST | `/api/v1/token/refresh/` | Refresh JWT access token |
| GET | `/api/v1/reports/` | List tenant reports |
| POST | `/api/v1/reports/` | Create a draft report |
| GET | `/api/v1/reports/{id}/` | Report detail |
| POST | `/api/v1/reports/{id}/transition/` | Transition report status |

## Phase roadmap

- **Phase 1** (current): Auth, organizations, users, reports, read models, Celery, tests
- **Phase 2**: Ingestion payload, OutboxEvent, S3/MinIO, PgBouncer
- **Phase 3**: Debezium CDC, event-driven cache invalidation
- **Phase 4**: pgvector embeddings, HNSW index, semantic search
- **Phase 5**: Taxonomy nodes, location hierarchy, ltree + PostGIS
