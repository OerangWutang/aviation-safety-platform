from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsTenantMember(BasePermission):
    """Allow access only to users whose organization matches the object's organization."""

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)

    def has_object_permission(self, request, view, obj):
        org_id = getattr(obj, "organization_id", None)
        return org_id is not None and str(org_id) == str(request.user.organization_id)


class IsTenantMemberReadOnly(IsTenantMember):
    """Tenant member with read-only access."""

    def has_permission(self, request, view):
        return (
            super().has_permission(request, view)
            and request.method in SAFE_METHODS
        )


class IsAdminOrSafetyOfficer(IsTenantMember):
    """Only admin or safety_officer roles can write."""

    WRITE_ROLES = {"admin", "safety_officer"}

    def has_permission(self, request, view):
        if not super().has_permission(request, view):
            return False
        if request.method in SAFE_METHODS:
            return True
        return request.user.role in self.WRITE_ROLES
