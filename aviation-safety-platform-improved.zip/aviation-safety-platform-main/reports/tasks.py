import logging
from celery import shared_task
from django.utils import timezone

logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3, default_retry_delay=10)
def refresh_report_read_model_task(self, report_id: str):
    from .models import Report, ReportReadModel
    try:
        report = (
            Report.objects
            .select_related("organization", "created_by", "assigned_to")
            .get(id=report_id)
        )
    except Report.DoesNotExist:
        logger.warning("refresh_report_read_model_task: Report %s not found", report_id)
        return

    document = {
        "id": str(report.id),
        "tracking_number": report.tracking_number,
        "status": report.status,
        "event_date": report.event_date.isoformat() if report.event_date else None,
        "narrative": report.narrative,
        "occurrence_category": report.occurrence_category,
        "severity": report.severity,
        "risk_level": report.risk_level,
        "phase_of_flight": report.phase_of_flight,
        "location": report.location,
        "airport_icao": report.airport_icao,
        "aircraft_registration": report.aircraft_registration,
        "aircraft_type": report.aircraft_type,
        "flight_number": report.flight_number,
        "confidential": report.confidential,
        "assigned_to_id": str(report.assigned_to_id) if report.assigned_to_id else None,
        "assigned_to_email": report.assigned_to.email if report.assigned_to_id else None,
        "review_due_at": report.review_due_at.isoformat() if report.review_due_at else None,
        "investigation_summary": report.investigation_summary,
        "corrective_actions": report.corrective_actions,
        "organization_id": str(report.organization_id),
        "organization_name": report.organization.name,
        "created_by_id": str(report.created_by_id),
        "created_by_email": report.created_by.email,
        "version": report.version,
        "created_at": report.created_at.isoformat(),
        "updated_at": report.updated_at.isoformat(),
    }
    ReportReadModel.objects.update_or_create(
        report=report,
        defaults={
            "document": document,
            "document_version": report.version,
            "refreshed_at": timezone.now(),
        },
    )
    logger.info("Refreshed read model for Report %s", report_id)
