from datetime import date, datetime
from decimal import Decimal
from uuid import UUID

from django.db import transaction
from django.shortcuts import get_object_or_404
from rest_framework import generics, status
from rest_framework.exceptions import PermissionDenied, ValidationError
from rest_framework.response import Response
from rest_framework.views import APIView

from core.permissions import IsTenantMember
from .models import Report, ReportEventType, ReportStatus
from .serializers import (
    ReportCreateSerializer,
    ReportDetailSerializer,
    ReportEventSerializer,
    ReportListSerializer,
    ReportStatusTransitionSerializer,
    ReportUpdateSerializer,
)
from .tasks import refresh_report_read_model_task


def _json_safe(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, Decimal):
        return str(value)
    if hasattr(value, "pk"):
        return str(value.pk)
    return value


class ReportListCreateView(generics.ListCreateAPIView):
    permission_classes = [IsTenantMember]

    def get_serializer_class(self):
        if self.request.method == "POST":
            return ReportCreateSerializer
        return ReportListSerializer

    def get_queryset(self):
        qs = (
            Report.objects
            .filter(organization=self.request.user.organization)
            .select_related("created_by", "assigned_to")
        )
        status_filter = self.request.query_params.get("status")
        if status_filter:
            valid_statuses = {choice.value for choice in ReportStatus}
            if status_filter not in valid_statuses:
                raise ValidationError({"status": "Unknown report status."})
            qs = qs.filter(status=status_filter)
        risk_filter = self.request.query_params.get("risk_level")
        if risk_filter:
            qs = qs.filter(risk_level=risk_filter)
        severity_filter = self.request.query_params.get("severity")
        if severity_filter:
            qs = qs.filter(severity=severity_filter)
        category_filter = self.request.query_params.get("occurrence_category")
        if category_filter:
            qs = qs.filter(occurrence_category=category_filter)
        return qs

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        with transaction.atomic():
            report = serializer.save()
            report.record_event(
                event_type=ReportEventType.CREATED,
                actor=request.user,
                metadata={"source": "api"},
            )
        transaction.on_commit(lambda: refresh_report_read_model_task.delay(str(report.id)))
        return Response(
            ReportDetailSerializer(report, context=self.get_serializer_context()).data,
            status=status.HTTP_201_CREATED,
        )


class ReportDetailView(generics.RetrieveUpdateAPIView):
    permission_classes = [IsTenantMember]
    lookup_field = "id"

    def get_serializer_class(self):
        if self.request.method in {"PUT", "PATCH"}:
            return ReportUpdateSerializer
        return ReportDetailSerializer

    def get_queryset(self):
        return (
            Report.objects
            .filter(organization=self.request.user.organization)
            .select_related("organization", "created_by", "assigned_to")
            .prefetch_related("events")
        )

    def get_object(self):
        obj = super().get_object()
        self.check_object_permissions(self.request, obj)
        return obj

    def update(self, request, *args, **kwargs):
        partial = kwargs.pop("partial", False)
        with transaction.atomic():
            report = get_object_or_404(
                self.get_queryset().select_for_update(),
                id=kwargs["id"],
            )
            self.check_object_permissions(request, report)
            if not report.can_be_edited_by(request.user):
                raise PermissionDenied("This report cannot be edited by you in its current status.")

            serializer = ReportUpdateSerializer(
                report,
                data=request.data,
                partial=partial,
                context=self.get_serializer_context(),
            )
            serializer.is_valid(raise_exception=True)
            changes = {}
            update_fields = []
            for field, value in serializer.validated_data.items():
                old_value = getattr(report, field)
                if old_value != value:
                    changes[field] = {
                        "from": _json_safe(old_value),
                        "to": _json_safe(value),
                    }
                    setattr(report, field, value)
                    update_fields.append(field)

            if changes:
                report.version += 1
                update_fields.extend(["version", "updated_at"])
                report.save(update_fields=update_fields)
                event_type = (
                    ReportEventType.ASSIGNED
                    if set(changes) == {"assigned_to"}
                    else ReportEventType.CONTENT_UPDATED
                )
                report.record_event(
                    event_type=event_type,
                    actor=request.user,
                    metadata={"changes": changes},
                )

        if changes:
            transaction.on_commit(lambda: refresh_report_read_model_task.delay(str(report.id)))
        return Response(ReportDetailSerializer(report, context=self.get_serializer_context()).data)


class ReportTransitionView(APIView):
    permission_classes = [IsTenantMember]

    def post(self, request, id):
        with transaction.atomic():
            report = get_object_or_404(
                Report.objects
                .select_for_update()
                .select_related("organization", "created_by", "assigned_to")
                .filter(organization=request.user.organization),
                id=id,
            )
            self.check_object_permissions(request, report)
            serializer = ReportStatusTransitionSerializer(
                data=request.data,
                context={"report": report, "request": request},
            )
            serializer.is_valid(raise_exception=True)
            new_status = serializer.validated_data["status"]
            old_status, new_status = report.transition_to(new_status)
            report.save(update_fields=["status", "version", "updated_at"])
            report.record_event(
                event_type=ReportEventType.STATUS_TRANSITIONED,
                actor=request.user,
                from_status=old_status,
                to_status=new_status,
                comment=serializer.validated_data.get("comment", ""),
            )
        transaction.on_commit(lambda: refresh_report_read_model_task.delay(str(report.id)))
        return Response(ReportDetailSerializer(report, context={"request": request}).data)


class ReportEventListView(generics.ListAPIView):
    permission_classes = [IsTenantMember]
    serializer_class = ReportEventSerializer

    def get_queryset(self):
        report = get_object_or_404(
            Report.objects.filter(organization=self.request.user.organization),
            id=self.kwargs["id"],
        )
        self.check_object_permissions(self.request, report)
        return report.events.select_related("actor")
