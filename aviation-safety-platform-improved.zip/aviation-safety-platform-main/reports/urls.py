from django.urls import path
from .views import ReportDetailView, ReportEventListView, ReportListCreateView, ReportTransitionView

urlpatterns = [
    path("reports/", ReportListCreateView.as_view(), name="report_list_create"),
    path("reports/<uuid:id>/", ReportDetailView.as_view(), name="report_detail"),
    path("reports/<uuid:id>/transition/", ReportTransitionView.as_view(), name="report_transition"),
    path("reports/<uuid:id>/events/", ReportEventListView.as_view(), name="report_events"),
]
