from django.contrib import admin
from .models import Report, ReportEvent, ReportReadModel, ReportTrackingSequence


class ReportEventInline(admin.TabularInline):
    model = ReportEvent
    extra = 0
    can_delete = False
    readonly_fields = [
        "event_type",
        "actor",
        "from_status",
        "to_status",
        "comment",
        "metadata",
        "report_version",
        "created_at",
    ]

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = [
        "tracking_number",
        "organization",
        "status",
        "risk_level",
        "severity",
        "occurrence_category",
        "assigned_to",
        "version",
        "event_date",
        "created_at",
    ]
    list_filter = ["status", "risk_level", "severity", "occurrence_category", "organization", "confidential"]
    search_fields = [
        "tracking_number",
        "narrative",
        "airport_icao",
        "aircraft_registration",
        "flight_number",
    ]
    readonly_fields = ["tracking_number", "version", "created_at", "updated_at"]
    inlines = [ReportEventInline]


@admin.register(ReportEvent)
class ReportEventAdmin(admin.ModelAdmin):
    list_display = ["report", "event_type", "actor", "from_status", "to_status", "report_version", "created_at"]
    list_filter = ["event_type", "organization", "from_status", "to_status"]
    search_fields = ["report__tracking_number", "actor__email", "comment"]
    readonly_fields = [
        "report",
        "organization",
        "actor",
        "event_type",
        "from_status",
        "to_status",
        "comment",
        "metadata",
        "report_version",
        "created_at",
    ]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False


@admin.register(ReportReadModel)
class ReportReadModelAdmin(admin.ModelAdmin):
    list_display = ["report", "document_version", "refreshed_at"]
    readonly_fields = ["report", "document", "document_version", "refreshed_at"]


@admin.register(ReportTrackingSequence)
class ReportTrackingSequenceAdmin(admin.ModelAdmin):
    list_display = ["organization", "year", "next_number", "updated_at"]
    readonly_fields = ["organization", "year", "next_number", "created_at", "updated_at"]
