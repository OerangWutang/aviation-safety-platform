from django.utils import timezone
from rest_framework import serializers

from users.models import Role
from .models import (
    Report,
    ReportEvent,
    ReportStatus,
    STATUS_TRANSITIONS,
)


REPORT_DOMAIN_FIELDS = [
    "event_date",
    "narrative",
    "occurrence_category",
    "severity",
    "risk_level",
    "phase_of_flight",
    "location",
    "airport_icao",
    "aircraft_registration",
    "aircraft_type",
    "flight_number",
    "confidential",
    "assigned_to",
    "review_due_at",
    "investigation_summary",
    "corrective_actions",
]


class ReportValidationMixin:
    def validate_event_date(self, value):
        if value and value > timezone.localdate():
            raise serializers.ValidationError("Event date cannot be in the future.")
        return value

    def validate_airport_icao(self, value):
        return value.upper() if value else value

    def validate_assigned_to(self, value):
        if value is None:
            return value
        request = self.context.get("request")
        if request and value.organization_id != request.user.organization_id:
            raise serializers.ValidationError("Assigned user must belong to your organization.")
        if value.role not in {Role.ADMIN, Role.SAFETY_OFFICER}:
            raise serializers.ValidationError("Reports can only be assigned to an admin or safety officer.")
        return value


class ReportCreateSerializer(ReportValidationMixin, serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = [
            "event_date",
            "narrative",
            "occurrence_category",
            "severity",
            "risk_level",
            "phase_of_flight",
            "location",
            "airport_icao",
            "aircraft_registration",
            "aircraft_type",
            "flight_number",
            "confidential",
        ]

    def create(self, validated_data):
        request = self.context["request"]
        validated_data["organization"] = request.user.organization
        validated_data["created_by"] = request.user
        return super().create(validated_data)


class ReportUpdateSerializer(ReportValidationMixin, serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = REPORT_DOMAIN_FIELDS
        extra_kwargs = {field: {"required": False} for field in REPORT_DOMAIN_FIELDS}


class ReportListSerializer(serializers.ModelSerializer):
    created_by_email = serializers.EmailField(source="created_by.email", read_only=True)
    assigned_to_email = serializers.EmailField(source="assigned_to.email", read_only=True)

    class Meta:
        model = Report
        fields = [
            "id",
            "tracking_number",
            "status",
            "event_date",
            "occurrence_category",
            "severity",
            "risk_level",
            "phase_of_flight",
            "location",
            "airport_icao",
            "aircraft_registration",
            "flight_number",
            "confidential",
            "created_by",
            "created_by_email",
            "assigned_to",
            "assigned_to_email",
            "created_at",
            "updated_at",
            "version",
        ]


class ReportEventSerializer(serializers.ModelSerializer):
    actor_email = serializers.EmailField(source="actor.email", read_only=True)

    class Meta:
        model = ReportEvent
        fields = [
            "id",
            "event_type",
            "actor",
            "actor_email",
            "from_status",
            "to_status",
            "comment",
            "metadata",
            "report_version",
            "created_at",
        ]
        read_only_fields = fields


class ReportDetailSerializer(serializers.ModelSerializer):
    allowed_transitions = serializers.SerializerMethodField()
    created_by_email = serializers.EmailField(source="created_by.email", read_only=True)
    assigned_to_email = serializers.EmailField(source="assigned_to.email", read_only=True)
    organization_name = serializers.CharField(source="organization.name", read_only=True)
    recent_events = serializers.SerializerMethodField()

    class Meta:
        model = Report
        fields = [
            "id",
            "tracking_number",
            "organization",
            "organization_name",
            "created_by",
            "created_by_email",
            "event_date",
            "narrative",
            "occurrence_category",
            "severity",
            "risk_level",
            "phase_of_flight",
            "location",
            "airport_icao",
            "aircraft_registration",
            "aircraft_type",
            "flight_number",
            "confidential",
            "assigned_to",
            "assigned_to_email",
            "review_due_at",
            "investigation_summary",
            "corrective_actions",
            "status",
            "version",
            "created_at",
            "updated_at",
            "allowed_transitions",
            "recent_events",
        ]
        read_only_fields = [
            "id",
            "tracking_number",
            "organization",
            "organization_name",
            "created_by",
            "created_by_email",
            "status",
            "version",
            "created_at",
            "updated_at",
            "allowed_transitions",
            "recent_events",
        ]

    def get_allowed_transitions(self, obj) -> list[str]:
        request = self.context.get("request")
        user = getattr(request, "user", None)
        return [
            status
            for status in STATUS_TRANSITIONS.get(obj.status, [])
            if obj.can_transition_by(user, status)
        ]

    def get_recent_events(self, obj):
        events = obj.events.select_related("actor").order_by("-created_at")[:5]
        return ReportEventSerializer(events, many=True).data


class ReportStatusTransitionSerializer(serializers.Serializer):
    status = serializers.ChoiceField(choices=ReportStatus.choices)
    comment = serializers.CharField(required=False, allow_blank=True, max_length=4000)

    def validate_status(self, new_status):
        report = self.context["report"]
        request = self.context["request"]
        if not report.can_transition_to(new_status):
            raise serializers.ValidationError(
                f"Cannot transition from '{report.status}' to '{new_status}'."
            )
        if not report.can_transition_by(request.user, new_status):
            raise serializers.ValidationError("You are not allowed to perform this transition.")
        return new_status

    def validate(self, attrs):
        report = self.context["report"]
        new_status = attrs["status"]
        if new_status == ReportStatus.UNDER_REVIEW and not report.narrative.strip():
            raise serializers.ValidationError({"narrative": "Narrative is required before submitting for review."})
        if new_status == ReportStatus.APPROVED_QUEUED and report.risk_level == "unknown":
            raise serializers.ValidationError({"risk_level": "Risk level must be set before approval."})
        return attrs
