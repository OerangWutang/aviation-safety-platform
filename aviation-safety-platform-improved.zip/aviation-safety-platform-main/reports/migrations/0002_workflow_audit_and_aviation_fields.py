import uuid
import django.core.validators
import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("reports", "0001_initial"),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name="ReportTrackingSequence",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("year", models.PositiveIntegerField()),
                ("next_number", models.PositiveIntegerField(default=1)),
                ("organization", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="report_tracking_sequences", to="organizations.organization")),
            ],
            options={"ordering": ["organization", "-year"]},
        ),
        migrations.AlterField(
            model_name="report",
            name="tracking_number",
            field=models.CharField(blank=True, editable=False, max_length=64, unique=True),
        ),
        migrations.AddField(
            model_name="report",
            name="occurrence_category",
            field=models.CharField(blank=True, choices=[("airprox", "Airprox / loss of separation"), ("bird_strike", "Bird strike"), ("runway_incident", "Runway incident"), ("ground_handling", "Ground handling"), ("maintenance", "Maintenance"), ("security", "Security"), ("weather", "Weather"), ("technical", "Technical"), ("human_factors", "Human factors"), ("other", "Other")], default="", max_length=50),
        ),
        migrations.AddField(
            model_name="report",
            name="severity",
            field=models.CharField(choices=[("unknown", "Unknown"), ("low", "Low"), ("medium", "Medium"), ("high", "High"), ("critical", "Critical")], default="unknown", max_length=20),
        ),
        migrations.AddField(
            model_name="report",
            name="risk_level",
            field=models.CharField(choices=[("unknown", "Unknown"), ("low", "Low"), ("medium", "Medium"), ("high", "High"), ("extreme", "Extreme")], default="unknown", max_length=20),
        ),
        migrations.AddField(
            model_name="report",
            name="phase_of_flight",
            field=models.CharField(choices=[("unknown", "Unknown"), ("parked", "Parked"), ("taxi", "Taxi"), ("takeoff", "Takeoff"), ("climb", "Climb"), ("cruise", "Cruise"), ("descent", "Descent"), ("approach", "Approach"), ("landing", "Landing"), ("ground_operations", "Ground operations")], default="unknown", max_length=30),
        ),
        migrations.AddField(
            model_name="report",
            name="location",
            field=models.CharField(blank=True, default="", max_length=255),
        ),
        migrations.AddField(
            model_name="report",
            name="airport_icao",
            field=models.CharField(blank=True, default="", max_length=4, validators=[django.core.validators.RegexValidator(message="Use a four-letter uppercase ICAO airport code, for example EHAM.", regex="^[A-Z]{4}$")]),
        ),
        migrations.AddField(
            model_name="report",
            name="aircraft_registration",
            field=models.CharField(blank=True, default="", max_length=32),
        ),
        migrations.AddField(
            model_name="report",
            name="aircraft_type",
            field=models.CharField(blank=True, default="", max_length=80),
        ),
        migrations.AddField(
            model_name="report",
            name="flight_number",
            field=models.CharField(blank=True, default="", max_length=32),
        ),
        migrations.AddField(
            model_name="report",
            name="confidential",
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name="report",
            name="assigned_to",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="assigned_reports", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="report",
            name="review_due_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="report",
            name="investigation_summary",
            field=models.TextField(blank=True, default=""),
        ),
        migrations.AddField(
            model_name="report",
            name="corrective_actions",
            field=models.TextField(blank=True, default=""),
        ),
        migrations.CreateModel(
            name="ReportEvent",
            fields=[
                ("id", models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ("event_type", models.CharField(choices=[("created", "Created"), ("content_updated", "Content updated"), ("status_transitioned", "Status transitioned"), ("assigned", "Assigned"), ("commented", "Commented")], max_length=40)),
                ("from_status", models.CharField(blank=True, choices=[("draft", "Draft"), ("ingested", "Ingested"), ("validation_failed", "Validation Failed"), ("under_review", "Under Review"), ("requires_revision", "Requires Revision"), ("approved_queued", "Approved – Post-processing Queued"), ("published", "Published"), ("rejected", "Rejected"), ("archived", "Archived")], default="", max_length=30)),
                ("to_status", models.CharField(blank=True, choices=[("draft", "Draft"), ("ingested", "Ingested"), ("validation_failed", "Validation Failed"), ("under_review", "Under Review"), ("requires_revision", "Requires Revision"), ("approved_queued", "Approved – Post-processing Queued"), ("published", "Published"), ("rejected", "Rejected"), ("archived", "Archived")], default="", max_length=30)),
                ("comment", models.TextField(blank=True, default="")),
                ("metadata", models.JSONField(blank=True, default=dict)),
                ("report_version", models.PositiveIntegerField()),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("actor", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="report_events", to=settings.AUTH_USER_MODEL)),
                ("organization", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="report_events", to="organizations.organization")),
                ("report", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="events", to="reports.report")),
            ],
            options={"ordering": ["created_at"]},
        ),
        migrations.AddConstraint(
            model_name="reporttrackingsequence",
            constraint=models.UniqueConstraint(fields=("organization", "year"), name="unique_report_sequence_per_org_year"),
        ),
        migrations.AddIndex(
            model_name="report",
            index=models.Index(fields=["organization", "risk_level"], name="reports_org_risk_idx"),
        ),
        migrations.AddIndex(
            model_name="report",
            index=models.Index(fields=["organization", "severity"], name="reports_org_severity_idx"),
        ),
        migrations.AddIndex(
            model_name="report",
            index=models.Index(fields=["organization", "occurrence_category"], name="reports_org_category_idx"),
        ),
        migrations.AddIndex(
            model_name="reportevent",
            index=models.Index(fields=["organization", "created_at"], name="reportevent_org_created_idx"),
        ),
        migrations.AddIndex(
            model_name="reportevent",
            index=models.Index(fields=["report", "created_at"], name="reportevent_report_created_idx"),
        ),
        migrations.AddIndex(
            model_name="reportevent",
            index=models.Index(fields=["event_type"], name="reportevent_event_type_idx"),
        ),
    ]
