import uuid
from typing import Any

from django.conf import settings
from django.core.validators import RegexValidator
from django.db import models, transaction
from django.utils import timezone

from core.models import TimestampedModel
from users.models import Role


class ReportStatus(models.TextChoices):
    DRAFT = "draft", "Draft"
    INGESTED = "ingested", "Ingested"
    VALIDATION_FAILED = "validation_failed", "Validation Failed"
    UNDER_REVIEW = "under_review", "Under Review"
    REQUIRES_REVISION = "requires_revision", "Requires Revision"
    APPROVED_QUEUED = "approved_queued", "Approved – Post-processing Queued"
    PUBLISHED = "published", "Published"
    REJECTED = "rejected", "Rejected"
    ARCHIVED = "archived", "Archived"


class OccurrenceCategory(models.TextChoices):
    AIRPROX = "airprox", "Airprox / loss of separation"
    BIRD_STRIKE = "bird_strike", "Bird strike"
    RUNWAY_INCIDENT = "runway_incident", "Runway incident"
    GROUND_HANDLING = "ground_handling", "Ground handling"
    MAINTENANCE = "maintenance", "Maintenance"
    SECURITY = "security", "Security"
    WEATHER = "weather", "Weather"
    TECHNICAL = "technical", "Technical"
    HUMAN_FACTORS = "human_factors", "Human factors"
    OTHER = "other", "Other"


class Severity(models.TextChoices):
    UNKNOWN = "unknown", "Unknown"
    LOW = "low", "Low"
    MEDIUM = "medium", "Medium"
    HIGH = "high", "High"
    CRITICAL = "critical", "Critical"


class RiskLevel(models.TextChoices):
    UNKNOWN = "unknown", "Unknown"
    LOW = "low", "Low"
    MEDIUM = "medium", "Medium"
    HIGH = "high", "High"
    EXTREME = "extreme", "Extreme"


class PhaseOfFlight(models.TextChoices):
    UNKNOWN = "unknown", "Unknown"
    PARKED = "parked", "Parked"
    TAXI = "taxi", "Taxi"
    TAKEOFF = "takeoff", "Takeoff"
    CLIMB = "climb", "Climb"
    CRUISE = "cruise", "Cruise"
    DESCENT = "descent", "Descent"
    APPROACH = "approach", "Approach"
    LANDING = "landing", "Landing"
    GROUND_OPERATIONS = "ground_operations", "Ground operations"


class ReportEventType(models.TextChoices):
    CREATED = "created", "Created"
    CONTENT_UPDATED = "content_updated", "Content updated"
    STATUS_TRANSITIONED = "status_transitioned", "Status transitioned"
    ASSIGNED = "assigned", "Assigned"
    COMMENTED = "commented", "Commented"


STATUS_TRANSITIONS: dict[str, list[str]] = {
    ReportStatus.DRAFT: [ReportStatus.UNDER_REVIEW],
    ReportStatus.INGESTED: [ReportStatus.UNDER_REVIEW],
    ReportStatus.VALIDATION_FAILED: [ReportStatus.ARCHIVED],
    ReportStatus.UNDER_REVIEW: [
        ReportStatus.REQUIRES_REVISION,
        ReportStatus.APPROVED_QUEUED,
        ReportStatus.REJECTED,
    ],
    ReportStatus.REQUIRES_REVISION: [ReportStatus.UNDER_REVIEW],
    ReportStatus.APPROVED_QUEUED: [ReportStatus.PUBLISHED],
    ReportStatus.PUBLISHED: [ReportStatus.ARCHIVED],
    ReportStatus.REJECTED: [ReportStatus.ARCHIVED],
    ReportStatus.ARCHIVED: [],
}

FINAL_STATUSES = {
    ReportStatus.PUBLISHED,
    ReportStatus.REJECTED,
    ReportStatus.ARCHIVED,
}

CONTENT_EDITABLE_STATUSES = {
    ReportStatus.DRAFT,
    ReportStatus.REQUIRES_REVISION,
}

REVIEWER_ROLES = {Role.ADMIN, Role.SAFETY_OFFICER}
ADMIN_ONLY_TRANSITIONS = {
    (ReportStatus.PUBLISHED, ReportStatus.ARCHIVED),
    (ReportStatus.REJECTED, ReportStatus.ARCHIVED),
}
REVIEWER_TRANSITIONS = {
    (ReportStatus.INGESTED, ReportStatus.UNDER_REVIEW),
    (ReportStatus.VALIDATION_FAILED, ReportStatus.ARCHIVED),
    (ReportStatus.UNDER_REVIEW, ReportStatus.REQUIRES_REVISION),
    (ReportStatus.UNDER_REVIEW, ReportStatus.APPROVED_QUEUED),
    (ReportStatus.UNDER_REVIEW, ReportStatus.REJECTED),
    (ReportStatus.APPROVED_QUEUED, ReportStatus.PUBLISHED),
}
CREATOR_OR_REVIEWER_TRANSITIONS = {
    (ReportStatus.DRAFT, ReportStatus.UNDER_REVIEW),
    (ReportStatus.REQUIRES_REVISION, ReportStatus.UNDER_REVIEW),
}


def _generate_tracking_number() -> str:
    """Legacy fallback retained for older migrations and direct field defaults."""
    return f"ASP-LEGACY-{uuid.uuid4().hex[:8].upper()}"


class ReportTrackingSequence(TimestampedModel):
    organization = models.ForeignKey(
        "organizations.Organization",
        on_delete=models.CASCADE,
        related_name="report_tracking_sequences",
    )
    year = models.PositiveIntegerField()
    next_number = models.PositiveIntegerField(default=1)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["organization", "year"],
                name="unique_report_sequence_per_org_year",
            )
        ]
        ordering = ["organization", "-year"]

    def __str__(self):
        return f"{self.organization.slug}-{self.year}:{self.next_number}"


class Report(TimestampedModel):
    organization = models.ForeignKey(
        "organizations.Organization", on_delete=models.PROTECT, related_name="reports",
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="created_reports",
    )
    tracking_number = models.CharField(
        max_length=64, unique=True, editable=False, blank=True,
    )
    event_date = models.DateField(null=True, blank=True)
    narrative = models.TextField(blank=True, default="")
    status = models.CharField(
        max_length=30, choices=ReportStatus.choices, default=ReportStatus.DRAFT, db_index=True,
    )
    version = models.PositiveIntegerField(default=1)

    occurrence_category = models.CharField(
        max_length=50,
        choices=OccurrenceCategory.choices,
        blank=True,
        default="",
    )
    severity = models.CharField(
        max_length=20,
        choices=Severity.choices,
        default=Severity.UNKNOWN,
    )
    risk_level = models.CharField(
        max_length=20,
        choices=RiskLevel.choices,
        default=RiskLevel.UNKNOWN,
    )
    phase_of_flight = models.CharField(
        max_length=30,
        choices=PhaseOfFlight.choices,
        default=PhaseOfFlight.UNKNOWN,
    )
    location = models.CharField(max_length=255, blank=True, default="")
    airport_icao = models.CharField(
        max_length=4,
        blank=True,
        default="",
        validators=[
            RegexValidator(
                regex=r"^[A-Z]{4}$",
                message="Use a four-letter uppercase ICAO airport code, for example EHAM.",
            )
        ],
    )
    aircraft_registration = models.CharField(max_length=32, blank=True, default="")
    aircraft_type = models.CharField(max_length=80, blank=True, default="")
    flight_number = models.CharField(max_length=32, blank=True, default="")
    confidential = models.BooleanField(default=False)
    assigned_to = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="assigned_reports",
    )
    review_due_at = models.DateTimeField(null=True, blank=True)
    investigation_summary = models.TextField(blank=True, default="")
    corrective_actions = models.TextField(blank=True, default="")

    class Meta:
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["organization", "status"], name="reports_org_status_idx"),
            models.Index(fields=["organization", "-created_at"], name="reports_org_created_idx"),
            models.Index(fields=["organization", "risk_level"], name="reports_org_risk_idx"),
            models.Index(fields=["organization", "severity"], name="reports_org_severity_idx"),
            models.Index(fields=["organization", "occurrence_category"], name="reports_org_category_idx"),
        ]

    def __str__(self):
        return f"{self.tracking_number} [{self.status}]"

    @staticmethod
    def _tracking_prefix(organization) -> str:
        prefix = "".join(ch for ch in organization.slug.upper() if ch.isalnum())[:8]
        return prefix or "ORG"

    @classmethod
    def allocate_tracking_number(cls, organization) -> str:
        year = timezone.now().year
        with transaction.atomic():
            sequence, _ = (
                ReportTrackingSequence.objects.select_for_update().get_or_create(
                    organization=organization,
                    year=year,
                    defaults={"next_number": 1},
                )
            )
            number = sequence.next_number
            sequence.next_number = number + 1
            sequence.save(update_fields=["next_number", "updated_at"])
        return f"ASP-{cls._tracking_prefix(organization)}-{year}-{number:06d}"

    def save(self, *args, **kwargs):
        if not self.tracking_number:
            if not self.organization_id:
                raise ValueError("A report must have an organization before allocating a tracking number.")
            self.tracking_number = self.allocate_tracking_number(self.organization)
        if self.airport_icao:
            self.airport_icao = self.airport_icao.upper()
        super().save(*args, **kwargs)

    def can_transition_to(self, new_status: str) -> bool:
        return new_status in STATUS_TRANSITIONS.get(self.status, [])

    def can_be_edited_by(self, user) -> bool:
        if not user or not user.is_authenticated:
            return False
        if self.status not in CONTENT_EDITABLE_STATUSES:
            return False
        if user.role in REVIEWER_ROLES:
            return True
        return self.created_by_id == user.id

    def can_transition_by(self, user, new_status: str) -> bool:
        if not self.can_transition_to(new_status):
            return False
        if not user or not user.is_authenticated:
            return False
        transition = (self.status, new_status)
        if transition in ADMIN_ONLY_TRANSITIONS:
            return user.role == Role.ADMIN
        if transition in REVIEWER_TRANSITIONS:
            return user.role in REVIEWER_ROLES
        if transition in CREATOR_OR_REVIEWER_TRANSITIONS:
            return user.role in REVIEWER_ROLES or self.created_by_id == user.id
        return False

    def transition_to(self, new_status: str) -> tuple[str, str]:
        if not self.can_transition_to(new_status):
            raise ValueError(f"Cannot transition from '{self.status}' to '{new_status}'.")
        old_status = self.status
        self.status = new_status
        self.version += 1
        return old_status, new_status

    def record_event(
        self,
        *,
        event_type: str,
        actor=None,
        from_status: str = "",
        to_status: str = "",
        comment: str = "",
        metadata: dict[str, Any] | None = None,
    ):
        return ReportEvent.objects.create(
            report=self,
            actor=actor,
            organization=self.organization,
            event_type=event_type,
            from_status=from_status,
            to_status=to_status,
            comment=comment,
            metadata=metadata or {},
            report_version=self.version,
        )


class ReportEvent(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    report = models.ForeignKey(Report, on_delete=models.CASCADE, related_name="events")
    organization = models.ForeignKey(
        "organizations.Organization", on_delete=models.PROTECT, related_name="report_events",
    )
    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="report_events",
    )
    event_type = models.CharField(max_length=40, choices=ReportEventType.choices)
    from_status = models.CharField(max_length=30, choices=ReportStatus.choices, blank=True, default="")
    to_status = models.CharField(max_length=30, choices=ReportStatus.choices, blank=True, default="")
    comment = models.TextField(blank=True, default="")
    metadata = models.JSONField(default=dict, blank=True)
    report_version = models.PositiveIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]
        indexes = [
            models.Index(fields=["organization", "created_at"], name="reportevent_org_created_idx"),
            models.Index(fields=["report", "created_at"], name="reportevent_report_created_idx"),
            models.Index(fields=["event_type"], name="reportevent_event_type_idx"),
        ]

    def __str__(self):
        return f"{self.report.tracking_number} {self.event_type} v{self.report_version}"


class ReportReadModel(models.Model):
    report = models.OneToOneField(
        Report, on_delete=models.CASCADE, primary_key=True, related_name="read_model",
    )
    document = models.JSONField(default=dict)
    document_version = models.PositiveIntegerField(default=1)
    refreshed_at = models.DateTimeField(default=timezone.now)

    class Meta:
        verbose_name = "Report read model"

    def __str__(self):
        return f"ReadModel({self.report_id})"
