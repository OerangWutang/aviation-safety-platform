from django.urls import path
from .views import HealthCheckView, LiveCheckView, ReadyCheckView

urlpatterns = [
    path("health/", HealthCheckView.as_view(), name="health_check"),
    path("health/live/", LiveCheckView.as_view(), name="health_live"),
    path("health/ready/", ReadyCheckView.as_view(), name="health_ready"),
]
