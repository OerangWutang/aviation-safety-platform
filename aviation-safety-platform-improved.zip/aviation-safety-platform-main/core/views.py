from django.core.cache import caches
from django.db import connections
from django.db.utils import OperationalError
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView


class LiveCheckView(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request):
        return Response({"status": "ok"})


class ReadyCheckView(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request):
        checks = {"database": False, "cache": False}
        http_status = status.HTTP_200_OK

        try:
            with connections["default"].cursor() as cursor:
                cursor.execute("SELECT 1")
                cursor.fetchone()
            checks["database"] = True
        except OperationalError:
            http_status = status.HTTP_503_SERVICE_UNAVAILABLE

        try:
            cache = caches["default"]
            cache.set("health:ready", "ok", timeout=5)
            checks["cache"] = cache.get("health:ready") == "ok"
        except Exception:
            http_status = status.HTTP_503_SERVICE_UNAVAILABLE

        if not all(checks.values()):
            http_status = status.HTTP_503_SERVICE_UNAVAILABLE

        return Response(
            {"status": "ok" if http_status == status.HTTP_200_OK else "degraded", "checks": checks},
            status=http_status,
        )


HealthCheckView = LiveCheckView
