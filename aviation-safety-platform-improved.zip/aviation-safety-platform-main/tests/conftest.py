import pytest
from organizations.models import Organization
from users.models import AppUser, Role


@pytest.fixture
def org(db):
    return Organization.objects.create(name="Test Org", slug="test-org")


@pytest.fixture
def analyst(db, org):
    return AppUser.objects.create_user(
        email="analyst@test.org",
        organization=org,
        password="testpass123",
        role=Role.ANALYST,
    )


@pytest.fixture
def safety_officer(db, org):
    return AppUser.objects.create_user(
        email="safety@test.org",
        organization=org,
        password="testpass123",
        role=Role.SAFETY_OFFICER,
    )


@pytest.fixture
def admin_user(db, org):
    return AppUser.objects.create_user(
        email="admin@test.org",
        organization=org,
        password="testpass123",
        role=Role.ADMIN,
        is_staff=True,
    )


@pytest.fixture
def api_client():
    from rest_framework.test import APIClient
    return APIClient()


def _authenticated_client(api_client, user):
    from rest_framework_simplejwt.tokens import RefreshToken
    token = RefreshToken.for_user(user)
    api_client.credentials(HTTP_AUTHORIZATION=f"Bearer {token.access_token}")
    return api_client


@pytest.fixture
def analyst_client(api_client, analyst):
    return _authenticated_client(api_client, analyst)


@pytest.fixture
def safety_client(api_client, safety_officer):
    return _authenticated_client(api_client, safety_officer)


@pytest.fixture
def admin_client(api_client, admin_user):
    return _authenticated_client(api_client, admin_user)
