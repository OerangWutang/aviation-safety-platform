import pytest
from reports.models import Report, ReportEvent, ReportEventType, ReportStatus


@pytest.mark.django_db
def test_create_report(analyst_client):
    response = analyst_client.post(
        "/api/v1/reports/",
        {
            "event_date": "2026-05-01",
            "narrative": "Bird strike on final approach.",
            "occurrence_category": "bird_strike",
            "airport_icao": "EHAM",
            "phase_of_flight": "approach",
            "severity": "medium",
            "risk_level": "medium",
        },
    )
    assert response.status_code == 201
    data = response.json()
    assert data["status"] == ReportStatus.DRAFT
    assert data["version"] == 1
    assert data["tracking_number"].startswith("ASP-TESTORG-")
    assert data["occurrence_category"] == "bird_strike"
    assert data["airport_icao"] == "EHAM"
    assert ReportEvent.objects.filter(event_type=ReportEventType.CREATED).count() == 1


@pytest.mark.django_db
def test_list_reports_scoped_to_tenant(analyst_client, analyst, org, db):
    from organizations.models import Organization
    from users.models import AppUser, Role

    Report.objects.create(organization=org, created_by=analyst)

    other_org = Organization.objects.create(name="Other Org", slug="other-org")
    other_user = AppUser.objects.create_user(
        email="other@other.org", organization=other_org, password="pass", role=Role.ANALYST,
    )
    Report.objects.create(organization=other_org, created_by=other_user)

    response = analyst_client.get("/api/v1/reports/")
    assert response.status_code == 200
    result_ids = [r["id"] for r in response.json()["results"]]
    assert all(
        str(Report.objects.get(id=rid).organization_id) == str(org.id)
        for rid in result_ids
    )


@pytest.mark.django_db
def test_creator_can_submit_own_draft_for_review(analyst_client, analyst, org):
    report = Report.objects.create(
        organization=org,
        created_by=analyst,
        narrative="Unstable approach reported.",
    )
    response = analyst_client.post(
        f"/api/v1/reports/{report.id}/transition/",
        {"status": ReportStatus.UNDER_REVIEW, "comment": "Ready for review."},
    )
    assert response.status_code == 200
    report.refresh_from_db()
    assert report.status == ReportStatus.UNDER_REVIEW
    assert report.version == 2
    event = report.events.get(event_type=ReportEventType.STATUS_TRANSITIONED)
    assert event.from_status == ReportStatus.DRAFT
    assert event.to_status == ReportStatus.UNDER_REVIEW


@pytest.mark.django_db
def test_submit_requires_narrative(analyst_client, analyst, org):
    report = Report.objects.create(organization=org, created_by=analyst)
    response = analyst_client.post(
        f"/api/v1/reports/{report.id}/transition/",
        {"status": ReportStatus.UNDER_REVIEW},
    )
    assert response.status_code == 400


@pytest.mark.django_db
def test_analyst_cannot_approve_report(analyst_client, analyst, org):
    report = Report.objects.create(
        organization=org,
        created_by=analyst,
        status=ReportStatus.UNDER_REVIEW,
        narrative="Runway incursion.",
        risk_level="high",
    )
    response = analyst_client.post(
        f"/api/v1/reports/{report.id}/transition/",
        {"status": ReportStatus.APPROVED_QUEUED},
    )
    assert response.status_code == 400
    report.refresh_from_db()
    assert report.status == ReportStatus.UNDER_REVIEW


@pytest.mark.django_db
def test_safety_officer_can_approve_report(safety_client, analyst, org):
    report = Report.objects.create(
        organization=org,
        created_by=analyst,
        status=ReportStatus.UNDER_REVIEW,
        narrative="Runway incursion.",
        risk_level="high",
    )
    response = safety_client.post(
        f"/api/v1/reports/{report.id}/transition/",
        {"status": ReportStatus.APPROVED_QUEUED, "comment": "Risk assessment complete."},
    )
    assert response.status_code == 200
    report.refresh_from_db()
    assert report.status == ReportStatus.APPROVED_QUEUED
    assert report.version == 2


@pytest.mark.django_db
def test_invalid_status_transition_rejected(safety_client, analyst, org):
    report = Report.objects.create(organization=org, created_by=analyst, narrative="Bird strike.")
    response = safety_client.post(
        f"/api/v1/reports/{report.id}/transition/",
        {"status": ReportStatus.PUBLISHED},
    )
    assert response.status_code == 400


@pytest.mark.django_db
def test_report_detail_update_increments_version_and_records_event(analyst_client, analyst, org):
    report = Report.objects.create(organization=org, created_by=analyst)
    response = analyst_client.patch(
        f"/api/v1/reports/{report.id}/",
        {"status": ReportStatus.UNDER_REVIEW, "narrative": "Updated narrative"},
    )
    assert response.status_code == 200
    report.refresh_from_db()
    assert report.status == ReportStatus.DRAFT
    assert report.version == 2
    assert report.narrative == "Updated narrative"
    assert report.events.filter(event_type=ReportEventType.CONTENT_UPDATED).exists()


@pytest.mark.django_db
def test_report_under_review_cannot_be_edited_by_creator(analyst_client, analyst, org):
    report = Report.objects.create(
        organization=org,
        created_by=analyst,
        status=ReportStatus.UNDER_REVIEW,
        narrative="Submitted report.",
    )
    response = analyst_client.patch(
        f"/api/v1/reports/{report.id}/",
        {"narrative": "Should be blocked"},
    )
    assert response.status_code == 403


@pytest.mark.django_db
def test_cross_tenant_report_not_accessible(api_client, db):
    from organizations.models import Organization
    from users.models import AppUser
    from rest_framework_simplejwt.tokens import RefreshToken

    org_a = Organization.objects.create(name="Org A", slug="org-a")
    org_b = Organization.objects.create(name="Org B", slug="org-b")
    user_a = AppUser.objects.create_user(email="a@org.com", organization=org_a, password="pass")
    user_b = AppUser.objects.create_user(email="b@org.com", organization=org_b, password="pass")
    report_b = Report.objects.create(organization=org_b, created_by=user_b)

    token = RefreshToken.for_user(user_a)
    api_client.credentials(HTTP_AUTHORIZATION=f"Bearer {token.access_token}")
    response = api_client.get(f"/api/v1/reports/{report_b.id}/")
    assert response.status_code == 404


@pytest.mark.django_db
def test_events_endpoint_is_tenant_scoped(analyst_client, analyst, org):
    report = Report.objects.create(organization=org, created_by=analyst, narrative="Bird strike.")
    report.record_event(event_type=ReportEventType.CREATED, actor=analyst)
    response = analyst_client.get(f"/api/v1/reports/{report.id}/events/")
    assert response.status_code == 200
    assert len(response.json()["results"]) == 1
